//Use this file to implement Part One of your project

var animal;
